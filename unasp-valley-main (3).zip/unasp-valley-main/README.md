# unasp-valley
Jogo estilo stardew valley utilizando a biblioteca pygame para a matéria de Computação Gráfica

<p align="center">
<img src="http://img.shields.io/static/v1?label=STATUS&message=EM%20DESENVOLVIMENTO&color=GREEN&style=for-the-badge"/>
</p>

__________________
### Autores
| [<img src="https://avatars.githubusercontent.com/u/65495514?v=4" width=115><br><sub>Bruna Cordeiro</sub>](https://github.com/bruninhaout) | [<img src="https://avatars.githubusercontent.com/u/52930158?v=4" width=115><br><sub>Felipe Kadri</sub>](https://github.com/Felipe-Kadri) | [<img src="https://avatars.githubusercontent.com/u/16549819?v=4" width=115><br><sub>Nicolas Perejon</sub>](https://github.com/nperejon) | [<img src="https://avatars.githubusercontent.com/u/80612412?v=4" width=115><br><sub>Vinicius Custodio</sub>](https://github.com/Vinnsious) 
| :---: | :---: | :---: | :---: |
